package com.yolk.onlinechatserver.bo;

import lombok.Data;

/**
 * WebSocket 的 JSON 格式消息对应的实体类
 *
 * @author yolk
 * @since 2025/10/20 12:00
 */
@Data
public class Message {

    // 是否为系统消息
    private boolean system = true;
    // 发送人
    private String fromUser;
    // 收件人
    private String toUser;
    // 消息内容
    private Object content;

    // 发送给全部用户的消息
    public static Message of(Object content) {
        Message message = new Message();
        message.setContent(content);
        return message;
    }

    // fromUser 发送给 toUser
    public static Message of(String fromUser, String toUser, Object content) {
        Message message = new Message();
        message.setSystem(false);
        message.setFromUser(fromUser);
        message.setToUser(toUser);
        message.setContent(content);
        return message;
    }

}
