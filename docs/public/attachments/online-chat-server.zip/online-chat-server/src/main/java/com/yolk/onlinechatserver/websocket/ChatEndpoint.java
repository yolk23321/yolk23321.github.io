package com.yolk.onlinechatserver.websocket;

import com.yolk.onlinechatserver.bo.Message;
import com.yolk.onlinechatserver.config.GetHttpSessionConfig;
import com.yolk.onlinechatserver.utils.JsonUtil;
import jakarta.servlet.http.HttpSession;
import jakarta.websocket.CloseReason;
import jakarta.websocket.EndpointConfig;
import jakarta.websocket.OnClose;
import jakarta.websocket.OnMessage;
import jakarta.websocket.OnOpen;
import jakarta.websocket.Session;
import jakarta.websocket.server.ServerEndpoint;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 聊天 WebSocket 端点
 *
 * @author yolk
 * @since 2025/10/20 03:09
 */
@Component
// configurator 属性指定当前端点使用的配置类，要求必须继承自 ServerEndpointConfig.Configurator
@ServerEndpoint(value = "/chat", configurator = GetHttpSessionConfig.class)
public class ChatEndpoint {

    /**
     * 存储所有在线用户的会话
     * key: username
     * value: session
     */
    private static final Map<String, Session> ONLINE_USERS = new ConcurrentHashMap<>();

    /**
     * 一个 Endpoint 实例对应一个客户端连接，所以可以将 HttpSession 作为成员变量存储，以便其他方法使用
     */
    private HttpSession httpSession;

    @OnOpen
    public void onOpen(Session session, EndpointConfig endpointConfig) {
        // 1.获取 HttpSession 并赋值给成员变量，以便其他方法使用
        this.httpSession = (HttpSession) endpointConfig.getUserProperties().get("HttpSession");
        String username = (String) this.httpSession.getAttribute("username");

        // 2.将当前用户的 WebSocket 会话存储到在线用户集合中
        ONLINE_USERS.put(username, session);

        // 2.广播消息，需要将登陆的所有用户推送给所有的客户端
        Message message = Message.of(ONLINE_USERS.keySet());
        // 转成字符串
        String messageStr = JsonUtil.toJson(message);
        broadcastOnlineUsers(messageStr);
    }

    /**
     * 广播给所有客户端当前在线用户列表
     *
     * @param message 广播的消息内容（系统消息）
     */
    private void broadcastOnlineUsers(String message) {
        // 广播给所有客户端
        for (Session session : ONLINE_USERS.values()) {
            try {
                // 发送消息
                session.getBasicRemote().sendText(message);
            } catch (IOException e) {
                // 记录日志，这里就简单打印堆栈信息
                e.printStackTrace();
            }
        }
    }

    @OnMessage
    public void onMessage(String message) {
        // 1.解析客户端发送的消息
        Message messageObj = JsonUtil.fromJsonNoThrow(message, Message.class);
        // 消息合格不合规则不做处理
        if (messageObj == null) {
            return;
        }

        // 2.获取接收消息的用户会话
        String toUser = messageObj.getToUser();
        Session session = ONLINE_USERS.get(toUser);

        // 3.如果接收用户在线，则发送消息
        if (session != null) {
            // 构建发送的消息
            String username = (String) this.httpSession.getAttribute("username");
            Message sendMessage = Message.of(username, toUser, messageObj.getContent());
            String sendMessageStr = JsonUtil.toJson(sendMessage);

            // 发送消息
            try {
                session.getBasicRemote().sendText(sendMessageStr);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @OnClose
    public void close(Session session, CloseReason closeReason) {
        // 1.从在线用户集合中移除当前用户
        String username = (String) this.httpSession.getAttribute("username");
        ONLINE_USERS.remove(username);

        // 2.广播消息，将最新的在线用户列表推送给所有客户端
        Message message = Message.of(ONLINE_USERS.keySet());
        String messageStr = JsonUtil.toJson(message);
        broadcastOnlineUsers(messageStr);
    }

}
