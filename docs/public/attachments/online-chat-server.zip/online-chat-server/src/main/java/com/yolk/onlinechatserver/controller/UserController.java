package com.yolk.onlinechatserver.controller;

import com.yolk.onlinechatserver.bo.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 用户 API
 *
 * @author yolk
 * @since 2025/10/20 12:00
 */
@RestController
@RequestMapping("/user")
public class UserController {

    /**
     * 登录
     *
     * @param user 提交的用户数据，包含用户名和密码
     */
    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody User user, HttpSession httpSession) {
        if (user == null || !"123456".equals(user.getPassword())) {
            return Map.of("code", 500, "message", "密码错误");
        }

        // 将用户名存入 session，以便客户端或者 WebSocket 使用
        httpSession.setAttribute("username", user.getUsername());
        return Map.of("code", 200, "message", "登录成功");
    }

    /**
     * 获取用户名
     */
    @GetMapping("/get-username")
    public Map<String, Object> getUsername(HttpSession httpSession) {
        // 从 session 中获取当前登录的用户名
        String username = (String) httpSession.getAttribute("username");

        return Map.of("code", 200, "data", username);
    }

}
