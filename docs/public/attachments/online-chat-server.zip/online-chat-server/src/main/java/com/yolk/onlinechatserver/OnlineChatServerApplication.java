package com.yolk.onlinechatserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineChatServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnlineChatServerApplication.class, args);
    }

}
