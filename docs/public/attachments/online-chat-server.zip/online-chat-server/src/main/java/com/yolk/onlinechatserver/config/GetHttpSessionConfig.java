package com.yolk.onlinechatserver.config;

import jakarta.servlet.http.HttpSession;
import jakarta.websocket.HandshakeResponse;
import jakarta.websocket.server.HandshakeRequest;
import jakarta.websocket.server.ServerEndpointConfig;

/**
 * 通过继承 ServerEndpointConfig.Configurator 类实现配置 WebSocket 端点的自定义行为
 * <p>
 * 这里主要修改握手过程，以便在 WebSocket 会话中访问 HTTP 会话
 *
 * @author yolk
 * @since 2025/10/20 14:43
 */
public class GetHttpSessionConfig extends ServerEndpointConfig.Configurator {

    /**
     * 修改握手过程
     *
     * @param sec      端点配置
     * @param request  握手请求
     * @param response 握手响应
     */
    @Override
    public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, HandshakeResponse response) {
        // 获取 HTTP 会话
        HttpSession session = (HttpSession) request.getHttpSession();

        // 将 http session 存储到 WebSocket 的用户属性中，以便后续使用
        sec.getUserProperties().put("HttpSession", session);

        super.modifyHandshake(sec, request, response);
    }


}
