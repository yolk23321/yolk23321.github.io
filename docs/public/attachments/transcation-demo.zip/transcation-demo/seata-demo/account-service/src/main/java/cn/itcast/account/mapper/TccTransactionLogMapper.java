package cn.itcast.account.mapper;

import cn.itcast.account.entity.TccTransactionLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


public interface TccTransactionLogMapper extends BaseMapper<TccTransactionLog> {
}
